INSERT INTO `clubfan` (`clubid`, `fanid`, `joinDate`, `state`) VALUES (1, 3, '2022-12-29 20:53:37', 1);
