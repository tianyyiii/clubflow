INSERT INTO `postimage` (`postId`, `imageId`, `order`) VALUES (1, 1, 1);
