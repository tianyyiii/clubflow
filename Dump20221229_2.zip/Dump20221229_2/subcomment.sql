INSERT INTO `subcomment` (`subcommentId`, `subcommenter`, `context`, `commnetDate`, `comment`, `replyWho`, `thumbs`) VALUES (1, 2, 'Thank you for your support!', '2015-12-20 10:01:00', 1, 3, 1);
INSERT INTO `subcomment` (`subcommentId`, `subcommenter`, `context`, `commnetDate`, `comment`, `replyWho`, `thumbs`) VALUES (2, 3, '梅西', '2022-12-21 16:32:28', NULL, NULL, 0);
