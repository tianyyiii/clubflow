INSERT INTO `comment` (`commentId`, `commenter`, `post`, `context`, `commentDate`, `thumbs`) VALUES (1, 3, 1, 'great!', '2015-12-20 10:01:00', 2);
