INSERT INTO `commnetthumb` (`commnetId`, `thumberId`, `lastThumbDate`, `state`) VALUES (1, 2, '2015-12-20 10:01:00', 1);
INSERT INTO `commnetthumb` (`commnetId`, `thumberId`, `lastThumbDate`, `state`) VALUES (1, 3, '2015-12-20 10:01:00', 1);
