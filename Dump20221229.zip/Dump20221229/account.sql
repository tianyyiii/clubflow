INSERT INTO `account` (`id`, `name`, `passwd`, `role`, `state`, `image`) VALUES (1, 'geyuan', 'geyuan', 1, 1, '1');
INSERT INTO `account` (`id`, `name`, `passwd`, `role`, `state`, `image`) VALUES (2, 'guitar club', 'guitar club', 2, 1, '1');
INSERT INTO `account` (`id`, `name`, `passwd`, `role`, `state`, `image`) VALUES (3, 'geyuanyuan', 'geyuanyuan', 3, 1, '1');
INSERT INTO `account` (`id`, `name`, `passwd`, `role`, `state`, `image`) VALUES (5, 'userr', 'user', 1, 1, NULL);
