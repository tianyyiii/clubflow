INSERT INTO `postthumb` (`postId`, `thumberId`, `lastThumbDate`, `state`) VALUES (1, 1, '2015-12-20 10:01:00', 1);
INSERT INTO `postthumb` (`postId`, `thumberId`, `lastThumbDate`, `state`) VALUES (3, 1, '2022-12-22 17:45:35', 1);
