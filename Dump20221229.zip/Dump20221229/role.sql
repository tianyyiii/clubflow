INSERT INTO `role` (`id`, `name`) VALUES (1, 'administrator');
INSERT INTO `role` (`id`, `name`) VALUES (2, 'official account');
INSERT INTO `role` (`id`, `name`) VALUES (3, 'common user');
INSERT INTO `role` (`id`, `name`) VALUES (4, 'black user');
